# Gói Mô Hình Phân Loại Rác Thải (TrashNet - MobileNetV2)

Gói sản phẩm này được xuất trực tiếp từ Google Colab sau khi huấn luyện và đánh giá trên bộ dữ liệu **TrashNet (6 lớp)**. Toàn bộ tệp tin đã sẵn sàng để tích hợp vào ứng dụng **Streamlit** trên máy tính cá nhân.

## 1. Cấu trúc thư mục trong file ZIP

```text
package_export/
├── models/
│   ├── waste_model.keras          # Mô hình Keras tốt nhất đã huấn luyện
│   ├── class_names.json           # Danh sách thứ tự 6 nhãn chuẩn
│   └── model_config.json          # Cấu hình kích thước ảnh, tiền xử lý và ánh xạ nhãn
├── evaluation_results/
│   ├── test_evaluation_metrics.json       # Các chỉ số Accuracy, Precision, Recall, F1 trên tập Test
│   ├── classification_report.txt          # Báo cáo chi tiết từng lớp
│   ├── confusion_matrix.csv               # Ma trận nhầm lẫn dạng bảng
│   ├── confusion_matrix.png               # Biểu đồ Confusion Matrix
│   ├── training_history.csv               # Lịch sử Loss và Accuracy qua các Epoch
│   ├── training_accuracy_loss.png         # Biểu đồ quá trình huấn luyện
│   └── sample_prediction_verification.png # Kết quả kiểm thử dự đoán trước khi đóng gói
├── sample_test_images/            # 6 ảnh mẫu (1 ảnh/lớp) để kiểm thử nhanh trên máy cá nhân
└── README.md                      # Tài liệu hướng dẫn sử dụng
```

## 2. Yêu cầu thư viện trên máy tính cá nhân

```bash
pip install tensorflow pillow numpy streamlit
```

## 3. Cách nạp mô hình và dự đoán chuẩn xác trong Python / Streamlit

```python
import json
from pathlib import Path
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

BASE_DIR = Path('.')
MODEL_PATH = BASE_DIR / 'models' / 'waste_model.keras'
CLASS_NAMES_PATH = BASE_DIR / 'models' / 'class_names.json'
CONFIG_PATH = BASE_DIR / 'models' / 'model_config.json'

model = tf.keras.models.load_model(MODEL_PATH)
with open(CLASS_NAMES_PATH, 'r', encoding='utf-8') as f:
    class_names = json.load(f)
with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
    config = json.load(f)

def predict_waste_image(image_input):
    if isinstance(image_input, (str, Path)):
        img = Image.open(image_input)
    else:
        img = image_input

    target_size = tuple(config.get('image_size', [224, 224]))
    img_rgb = img.convert('RGB').resize(target_size, Image.Resampling.BILINEAR)
    img_array = np.asarray(img_rgb, dtype=np.float32)
    batch_tensor = np.expand_dims(img_array, axis=0)

    has_builtin = config.get('preprocessing', {}).get('model_has_builtin_preprocess', False)
    if not has_builtin:
        batch_tensor = preprocess_input(batch_tensor.copy())

    probs = model.predict(batch_tensor, verbose=0)[0]
    best_idx = int(np.argmax(probs))
    predicted_label = class_names[best_idx]
    confidence = float(probs[best_idx]) * 100.0
    all_probabilities = {class_names[i]: float(probs[i]) * 100.0 for i in range(len(class_names))}
    return predicted_label, confidence, all_probabilities
```

## 4. Tóm tắt kết quả thực nghiệm trên tập Test độc lập

- **Số lượng mẫu kiểm thử (Test set)**: 380 ảnh
- **Test Accuracy**: 84.21%
- **Macro F1-Score**: 0.8270
- **Weighted F1-Score**: 0.8418
- **Thứ tự 6 nhãn cố định**: `['cardboard', 'glass', 'metal', 'paper', 'plastic', 'trash']`